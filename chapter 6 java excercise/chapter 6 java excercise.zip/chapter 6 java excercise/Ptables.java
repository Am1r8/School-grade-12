/**
Amirhosein Soleimanian
Grade 11 Computer Science
Mr.Benum
*/
public class Ptables {
    public static void main(String[] args) {
        System.out.print("x^1       x^2      x^3      x^4      x^5");
        System.out.print("  1         1        1        1        1");
        System.out.print("  2         4        8       16       32");
        System.out.print("  3         9       27       83      243");
        System.out.print("  4        16       64      256     1024");
        System.out.print("  5        25      125      625     3125");
        System.out.print("  6        36      216     1296     7776");
    }
}