/**
Amirhosein Soleimanian
Grade 11 Computer Science
Mr.Benum
*/


public class Evens {
    public static void main(String[] args) {
        int num = 1;  //Introduces the variable num
            while (num <= 20){    //A while loop that displays the even numbers between 1 and 20 by adding 1 to the initial number twice until it reaches 20.
            num = num + 1;
            System.out.println(num);
            num++;
        }
    }
}