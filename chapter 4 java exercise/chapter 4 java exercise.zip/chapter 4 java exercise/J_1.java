/* Date: 2022-03-23
* Class: ICS3U
* Teacher: Mr. Benum
* By: Amirhosein Soleimanian
*/

import java.util.Scanner;
public class J_1 {
    public static void main(String[] args)
    {
        Scanner r = new Scanner(System.in);
        Scanner s = new Scanner(System.in);
        int r2 = r.nextInt();
        int s2 = s.nextInt();
        int k = (r2 * 8) + (s2 * 3);
		System.out.print(k-28);
    }    
 }
